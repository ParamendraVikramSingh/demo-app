const express = require('express');
const cors = require('cors');

const requestIdMiddleware = require('./middleware/requestId.middleware');
const loggerMiddleware = require('./middleware/logger.middleware');
const errorMiddleware = require('./middleware/error.middleware');
const routes = require('./routes');

const app = express();

// ──────────────────────────────────────────────────────────────────────────────
// Middleware order matters:
// 1. requestId   — must be FIRST so every subsequent middleware/log has req.id
// 2. logger      — access log on response finish (needs req.id)
// 3. cors        — allow cross-origin
// 4. json parser — parse request body
// 5. routes
// 6. 404 handler
// 7. error middleware — must be LAST
// ──────────────────────────────────────────────────────────────────────────────

app.use(requestIdMiddleware);
app.use(loggerMiddleware);
app.use(cors());
app.use(express.json());

// All API routes under /api
app.use('/api', routes);

// 404 — any unmatched route
app.use((req, res) => {
  res.status(404).json({ success: false, message: `Route not found: ${req.method} ${req.originalUrl}` });
});

// Centralized error handler — must be last
app.use(errorMiddleware);

module.exports = app;
